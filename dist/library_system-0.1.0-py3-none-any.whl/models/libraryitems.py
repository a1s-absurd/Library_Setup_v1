class LibraryItems:
    def __init__(self, author, publication, title, item_type, location):
        self.author = author
        self.publication = publication
        self.title = title
        self.item_type = item_type
        self.location = location
    
    def add_item(self):
        pass
    
    def remove_item(self):
        pass
        



# class Itemtype:
#     def __init__(self, book, dvd, cd, mag):
#         self.book  = book
#         self.dvd = dvd
#         self.cd = cd
#         self.mag = mag

class Book:
    def __init__(self):
        pass
    
class DVD:
    def __init__(self):
        pass

class CD:
    def __init__(self):
        pass

class Mag:
    def __init__(self):
        pass