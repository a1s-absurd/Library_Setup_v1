from . import libraryitems

class Library:
    library_items: libraryitems.LibraryItems = []
    
    def inject_into_library(self, item):
        self.library_items.append(item)
    
    def search(self):
        pass